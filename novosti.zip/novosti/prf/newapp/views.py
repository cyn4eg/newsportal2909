from django.views.generic import ListView , DetailView # импортируем класс, который говорит нам о том, что в этом представлении мы будем выводить список объектов из БД
from .models import Post


class PostList(ListView):
    model = Post  # указываем модель, объекты которой мы будем выводить
    template_name = 'post_list.html'  # указываем имя шаблона, в котором будет лежать HTML, в котором будут все инструкции о том, как именно пользователю должны вывестись наши объекты
    context_object_name = 'posts'


class PostDetail(DetailView):
    model = Post  # модель всё та же
    template_name = 'posts.html'  # название шаблона
    context_object_name = 'post'  # название объекта

